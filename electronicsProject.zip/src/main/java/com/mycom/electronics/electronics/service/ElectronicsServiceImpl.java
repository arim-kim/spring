package com.mycom.electronics.electronics.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mycom.electronics.electronics.dto.ElectronicsDto;

@Service
public class ElectronicsServiceImpl implements ElectronicsService {

	@Override
	public int addElec(ElectronicsDto ele) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ElectronicsDto> listElec() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ElectronicsDto getDetail(String code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(String code) {
		// TODO Auto-generated method stub
		return 0;
	}

}
